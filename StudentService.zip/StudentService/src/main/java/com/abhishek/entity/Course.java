package com.abhishek.entity;

import lombok.Data;

@Data
public class Course {

	private Integer id;
	private String coursename;
	private double fees;
	private String duration;
}
