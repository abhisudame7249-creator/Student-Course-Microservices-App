package com.abhishek.service.impl;

public class StudentNotFoundEXception extends RuntimeException {

	public StudentNotFoundEXception(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
